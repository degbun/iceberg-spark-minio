```python
spark.stop()
```

 This Spark session is configured to use Apache Iceberg with a REST catalog and MinIO as S3-compatible storage.
It defines a custom catalog named "iceberg_catalog", connects it to the Iceberg REST service,
and sets the warehouse location where all Iceberg table data will be stored.
 MinIO credentials and endpoint are provided to allow Spark to read and write data to object storage.
 Before running this notebook, make sure to create a bucket named "warehouse" in the MinIO web interface.
This setup enables full Iceberg functionality such as table creation, inserts, snapshots, and optimizations.

![Capture d’écran du 2025-12-02 00-09-23.png](4830ddfa-8f5e-4985-89dd-96b9642105c2.png)



```python
from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("IcebergSparkWithMinIO") \
    .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions") \
    .config("spark.sql.catalog.iceberg_catalog", "org.apache.iceberg.spark.SparkCatalog") \
    .config("spark.sql.catalog.iceberg_catalog.type", "rest") \
    .config("spark.sql.catalog.iceberg_catalog.uri", "http://iceberg-rest:8181") \
    .config("spark.sql.catalog.iceberg_catalog.warehouse", "s3://warehouse/") \
    .config("spark.sql.catalog.iceberg_catalog.io-impl", "org.apache.iceberg.aws.s3.S3FileIO") \
    .config("spark.sql.catalog.iceberg_catalog.s3.endpoint", "http://minio:9000") \
    .config("spark.sql.catalog.iceberg_catalog.s3.access-key-id", "admin") \
    .config("spark.sql.catalog.iceberg_catalog.s3.secret-access-key", "password") \
    .config("spark.sql.catalog.iceberg_catalog.s3.path-style-access", "true") \
    .getOrCreate()
```

    25/12/05 22:21:59 WARN SparkSession: Using an existing Spark session; only runtime SQL configurations will take effect.



```python

```


```python
spark.sql("SHOW DATABASES IN iceberg_catalog").show()
```

    +---------+
    |namespace|
    +---------+
    |  default|
    +---------+
    



```python
spark.conf.get("spark.sql.catalog.iceberg_catalog")
```




    'org.apache.iceberg.spark.SparkCatalog'




```python
spark.conf.get("spark.sql.catalog.iceberg_catalog.warehouse")
```




    's3://warehouse/'




```python
spark.conf.get("spark.sql.catalog.iceberg_catalog.type")
```




    'rest'




```python
spark.conf.get("spark.sql.catalog.iceberg_catalog.uri")
```




    'http://iceberg-rest:8181'



It creates the default namespace in the iceberg_catalog if it doesn’t already exist


```python
spark.sql("""
    CREATE NAMESPACE IF NOT EXISTS iceberg_catalog.default
""")

```




    DataFrame[]



Let's create a table named : my_table


```python
spark.sql("""
    CREATE TABLE iceberg_catalog.default.my_table (
        id BIGINT,
        name STRING
    ) USING iceberg
""")
```




    DataFrame[]



This is the result in MinIO under the directory: warehouse/default/my_table.
We only see a metadata repository because no data has been inserted yet — only the table’s metadata has been created.

![image.png](95b478f6-fe25-485c-b43e-d2c128881fd4.png)

![image.png](bef4b024-6628-4440-8f87-3fbfd826598d.png)

Here is the content of metadata.json. As you can see, it stores all the metadata information about the table.

![image.png](b37b34c3-e86f-4283-955f-828c5e67536e.png)


```python
spark.sql("""
    SELECT * 
    FROM iceberg_catalog.default.my_table.history
    ORDER BY made_current_at DESC
    LIMIT 2
""").show(truncate=False)

```

    +-----------------------+-------------------+---------+-------------------+
    |made_current_at        |snapshot_id        |parent_id|is_current_ancestor|
    +-----------------------+-------------------+---------+-------------------+
    |2025-12-02 00:21:40.832|7127313601007651275|NULL     |true               |
    +-----------------------+-------------------+---------+-------------------+
    



```python
spark.sql("INSERT INTO iceberg_catalog.default.my_table VALUES (1, 'Alice'), (2, 'Bob')")
df = spark.sql("SELECT * FROM iceberg_catalog.default.my_table")
df.show()
```

    +---+-----+
    | id| name|
    +---+-----+
    |  1|Alice|
    |  2|  Bob|
    +---+-----+
    


Now we have data in the directoy : warehouse/default/my_table/data




![image.png](5283256a-bbca-412e-a430-29f9594d4c81.png)


We have four files:

00001-c04fed86-8176-4931-9084-5cc2f898532a.metadata.json is the new metadata file that the Iceberg table now points to.

snap-7127313601007651275-1-a71b3fd1-d8c2-4547-b676-8ddc56c2be46.avro represents the snapshot.

a71b3fd1-d8c2-4547-b676-8ddc56c2be46-m0.avro represents both the manifest file and the manifest list. Since we inserted only a few records, Iceberg optimized them by combining both into a single file. Normally, there would be two separate .avro files: one for the manifest list and another for the manifest files.






![image.png](a4f02684-6a23-41bb-aac3-c2931fd83bb0.png)


```python

```


```python

```


```python
df = spark.sql("SELECT * FROM iceberg_catalog.default.my_table")
df.show()
```

    +---+-----+
    | id| name|
    +---+-----+
    |  1|Alice|
    |  2|  Bob|
    +---+-----+
    


let's check the snapshot


```python
spark.sql("SELECT * FROM iceberg_catalog.default.my_table.snapshots").show()
```

    +--------------------+-------------------+---------+---------+--------------------+--------------------+
    |        committed_at|        snapshot_id|parent_id|operation|       manifest_list|             summary|
    +--------------------+-------------------+---------+---------+--------------------+--------------------+
    |2025-12-02 00:21:...|7127313601007651275|     NULL|   append|s3://warehouse/de...|{spark.app.id -> ...|
    +--------------------+-------------------+---------+---------+--------------------+--------------------+
    



```python
spark.sql("""
    SELECT * 
    FROM iceberg_catalog.default.my_table.history
    ORDER BY made_current_at DESC
    LIMIT 1
""").show(truncate=False)

```

    +-----------------------+-------------------+---------+-------------------+
    |made_current_at        |snapshot_id        |parent_id|is_current_ancestor|
    +-----------------------+-------------------+---------+-------------------+
    |2025-12-02 00:21:40.832|7127313601007651275|NULL     |true               |
    +-----------------------+-------------------+---------+-------------------+
    


let's check the inside of the snapshot id and the manifest file

## snapshot File
![image.png](5021b608-3a68-4d44-9092-273682999768.png)
In the snapshot file, we can see the number of data files associated with this snapshot, as well as a reference to the manifest file.
The manifest file then contains the paths to the actual data files that store the snapshot’s data.
## Manifest File

![Capture d’écran du 2025-12-05 22-36-31.png](d0dcd403-a4bc-413b-9eac-24aa41fa76cd.png)

The manifest file stores the ID of the snapshot it belongs to and the paths to the data files.


```python

```




```python

```


```python

```


```python
spark.sql('''UPDATE iceberg_catalog.default.my_table 
SET name = 'David'
WHERE id = 1''')
```




    DataFrame[]




```python
spark.sql("SELECT * FROM iceberg_catalog.default.my_table.snapshots").show()
```

    +--------------------+-------------------+-------------------+---------+--------------------+--------------------+
    |        committed_at|        snapshot_id|          parent_id|operation|       manifest_list|             summary|
    +--------------------+-------------------+-------------------+---------+--------------------+--------------------+
    |2025-12-02 00:21:...|7127313601007651275|               NULL|   append|s3://warehouse/de...|{spark.app.id -> ...|
    |2025-12-05 22:53:...|6323587189617479683|7127313601007651275|overwrite|s3://warehouse/de...|{spark.app.id -> ...|
    +--------------------+-------------------+-------------------+---------+--------------------+--------------------+
    








```python
latest_snapshot_id = spark.sql("SELECT snapshot_id FROM iceberg_catalog.default.my_table.snapshots ORDER BY committed_at DESC LIMIT 1").collect()[0][0]
print(latest_snapshot_id)
```

    6323587189617479683


After updating the data, we now have:

- A new snapshot: `snap-7127313601007651275-1-a71b3fd1-d8c2-4547-b676-8ddc56c2be46.avro`
- A new metadata file: `00002-e4654012-d9fd-405e-af75-901c70c8e1ba.metadata.json`
- Two new manifest files:  
  - `680e5788-2871-4fbe-83c4-6eee8bb97417-m0.avro`  
  - `680e5788-2871-4fbe-83c4-6eee8bb97417-m1.avro`

![Capture d’écran du 2025-12-05 22-56-00.png](2437cbac-998f-41e5-8c17-4c6e0cd59b37.png)

## Snapshot

We can see that the snapshot points to two manifest files, which together make up the manifest list for this snapshot.

![image.png](6c139ddb-edbb-4a56-afad-81719650c934.png)

## Data File

Finally, in the data files directory, we can see a new data file: 00000-7-88c42460-4cb9-4844-b3f4-93f30730be90-0-00001.parquet

![image.png](184ec6b1-372f-4007-b494-4ce804feada6.png)



```python
spark.sql(f'''SELECT * FROM iceberg_catalog.default.my_table.manifests WHERE added_snapshot_id = {latest_snapshot_id}''').show()
```

    +-------+--------------------+------+-----------------+-------------------+----------------------+-------------------------+------------------------+------------------------+---------------------------+--------------------------+-------------------+
    |content|                path|length|partition_spec_id|  added_snapshot_id|added_data_files_count|existing_data_files_count|deleted_data_files_count|added_delete_files_count|existing_delete_files_count|deleted_delete_files_count|partition_summaries|
    +-------+--------------------+------+-----------------+-------------------+----------------------+-------------------------+------------------------+------------------------+---------------------------+--------------------------+-------------------+
    |      0|s3://warehouse/de...|  7021|                0|6323587189617479683|                     1|                        0|                       0|                       0|                          0|                         0|                 []|
    |      0|s3://warehouse/de...|  7059|                0|6323587189617479683|                     0|                        1|                       1|                       0|                          0|                         0|                 []|
    +-------+--------------------+------+-----------------+-------------------+----------------------+-------------------------+------------------------+------------------------+---------------------------+--------------------------+-------------------+
    



```python

```
